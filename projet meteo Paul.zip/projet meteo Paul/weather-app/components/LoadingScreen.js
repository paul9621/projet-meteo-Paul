export const LoadingScreen = ({ loadingMessage }) => <h1>{loadingMessage}</h1>;
